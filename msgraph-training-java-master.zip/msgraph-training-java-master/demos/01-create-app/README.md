# Completed module: Create a Java console app

The version of the project in this directory reflects completing the tutorial up through [Create a Java console app](https://docs.microsoft.com/graph/tutorials/java?tutorial-step=1). If you use this version of the project, you need to complete the rest of the tutorial starting at [Register the app in the portal](https://docs.microsoft.com/graph/tutorials/java?tutorial-step=2).
